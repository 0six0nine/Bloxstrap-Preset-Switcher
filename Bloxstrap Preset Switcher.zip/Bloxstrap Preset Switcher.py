# Importing libraries
import json
import time
import sys
import logging
import argparse
import glob

from win32com.client import Dispatch
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(message)s")

# Constants
PARENT_PATH = Path(__file__).resolve().parent
DEFAULT_CLIENT_PATH = Path.home() / "AppData" / "Local" / "Bloxstrap" / "Modifications" / "ClientSettings"
DEFAULT_PRESETS_PATH = PARENT_PATH / "Presets"
DIRECTORIES_FILE = PARENT_PATH / "Directories.txt"
MAX_BACKUPS = 3

# Utility Functions
def fix_shortcut_path(): # i hate shortcuts
    paths = glob.glob(str(PARENT_PATH) + "\\*.lnk")
    shell = Dispatch("WScript.Shell")

    if len(paths) > 1:
        return None
    
    for path in paths:
        shortcut = shell.CreateShortCut(path)
        shortcut.TargetPath = str(PARENT_PATH / "main.py") 
        shortcut.Save()

def ensure_file_exists(file_path: Path):
    file_path.touch(exist_ok=True)

def validate_directory_input(prompt: str) -> Path:
    while True:
        path = Path(input(prompt)).expanduser().resolve()
        if path.exists() and path.is_dir():
            return path
        print("Invalid path. Please try again.")

def get_json_files(directory: Path):
    json_files = [f for f in directory.glob("*.json")]
    return json_files if json_files else None

def load_directories():
    ensure_file_exists(DIRECTORIES_FILE)
    with open(DIRECTORIES_FILE, "r") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]
    client = Path(lines[0]).expanduser() if len(lines) >= 1 else DEFAULT_CLIENT_PATH
    presets = Path(lines[1]).expanduser() if len(lines) >= 2 else DEFAULT_PRESETS_PATH
    return client, presets

def cleanup_old_backups(client_path: Path):
    """Remove oldest backups if more than MAX_BACKUPS exist."""
    backups = sorted(
        client_path.glob("ClientAppSettings_*.json.old"),
        key=lambda f: f.stat().st_mtime
    )
    if len(backups) > MAX_BACKUPS:
        num_to_delete = len(backups) - MAX_BACKUPS
        for old_backup in backups[:num_to_delete]:
            try:
                old_backup.unlink()
                logging.info(f"Deleted old backup: {old_backup.name}")
            except Exception as e:
                logging.warning(f"Could not delete {old_backup.name}: {e}")


def select_json_file(presets_path: Path):
    json_files = get_json_files(presets_path)
    if not json_files:
        logging.error("No JSON files found in the Presets directory.")
        sys.exit(1)

    if len(json_files) == 1:
        return json_files[0]

    print(f"{len(json_files)} JSON files found. Select one:")
    for i, file in enumerate(json_files, start=1):
        print(f"[{i}] {file.name}")

    while True:
        try:
            choice = int(input("Enter number: ")) - 1
            if 0 <= choice < len(json_files):
                return json_files[choice]
        except ValueError:
            pass
        print(f"Please enter a valid number between 1 and {len(json_files)}.")


def backup_and_replace(client_path: Path, preset_file: Path):
    dest_file = client_path / "ClientAppSettings.json"
    if dest_file.exists():
        timestamp = time.strftime("%Y%m%d-%H%M%S")
        backup_file = client_path / f"ClientAppSettings_{timestamp}.json.old"
        dest_file.rename(backup_file)
        logging.info(f"\nExisting config backed up: {backup_file.name}")
        cleanup_old_backups(client_path)  # Clean up after backup

    try:
        with open(preset_file, "r") as src:
            data = json.load(src)
    except json.JSONDecodeError:
        logging.error("Error: Selected preset file contains invalid JSON.")
        sys.exit(1)

    with open(dest_file, "w") as dest:
        json.dump(data, dest, indent=4)

    logging.info("ClientAppSettings.json has been overwritten successfully.")


def save_directories(client_path: Path, presets_path: Path):
    with open(DIRECTORIES_FILE, "w") as f:
        f.write(f"{client_path}\n{presets_path}")


def main():
    fix_shortcut_path()

    parser = argparse.ArgumentParser(description="Replace Roblox ClientAppSettings.json with a preset.")
    parser.add_argument("--client-path", type=str, help="Path to Bloxstrap's ClientSettings directory")
    parser.add_argument("--presets-path", type=str, help="Path to Presets directory")
    args = parser.parse_args()

    client_path, presets_path = load_directories()

    if args.client_path:
        client_path = Path(args.client_path).expanduser().resolve()
    if args.presets_path:
        presets_path = Path(args.presets_path).expanduser().resolve()

    while not client_path.is_dir():
        client_path = validate_directory_input("Current ClientSettings path is invalid. Enter a valid path: ")

    while not presets_path.is_dir():
        presets_path = validate_directory_input("Current Presets path is invalid. Enter a valid path: ")

    logging.info(f"\nBloxstrap ClientSettings path: {client_path}")
    logging.info(f"Preset directory path: {presets_path}\n")

    selected_preset = select_json_file(presets_path)
    backup_and_replace(client_path, selected_preset)
    save_directories(client_path, presets_path)

    logging.info("\nExiting...")
    time.sleep(1)

if __name__ == "__main__":
    main()